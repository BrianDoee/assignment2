package homework2;

public interface Scratcher {
	
	public void scratch();

}
