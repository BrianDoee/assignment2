package homework2;

public interface Swimmer {
	
	public void swim();

}
