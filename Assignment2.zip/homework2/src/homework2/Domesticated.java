package homework2;

public interface  Domesticated {
	public void walk();

	public void  greetHuman();

}
